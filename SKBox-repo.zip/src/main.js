const { app, BrowserWindow, ipcMain, dialog, shell, globalShortcut, safeStorage, Tray, Menu, Notification, nativeImage, screen, desktopCapturer, session } = require('electron');
const { spawn, execFile } = require('child_process');
const path = require('path'), fs = require('fs'), crypto = require('crypto'), os = require('os');
const { RemoteHost } = require('./lib/remote'), { PadMapper } = require('./lib/padmap'), bt = require('./lib/bluetooth'), wifi = require('./lib/wifi'), covers = require('./lib/covers'), { HelperClient } = require('./lib/helperClient');
const store = require('./lib/store').make(app.getPath('userData'));

const API_KEY = 'AIzaSyAm2A3omt2z1dnK2Z_TdwPk1GTYuYQYdUQ', PROJECT = 'sksmpmc-e4682';
const SITE = 'https://sksmpchat.netlify.app', SITE_HOSTS = ['sksmpchat.netlify.app'];
const COVER_DIR = () => path.join(app.getPath('userData'), 'covers');
const isWin = process.platform === 'win32';
const RENDERER = (f) => path.join(__dirname, '..', 'renderer', f);

if (!app.requestSingleInstanceLock()) app.quit();
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

const batteries = {};
let overlayOpaque = false, padTest = false, fgTarget = null, overlayTarget = null;
const helperInfo = { error: '', lastGuide: 0, guides: 0, lastKey: '', diag: [] };
let win = null, tray = null, kiosk = true, helper = null, game = null, backdrop = null, overlayWin = null, overlayOpen = false, musicWin = null, musicUser = '', musicVisible = false, padCount = 0;
const send = (ch, ...a) => { try { if (win && !win.isDestroyed()) win.webContents.send(ch, ...a); } catch {} try { if (overlayWin && !overlayWin.isDestroyed()) overlayWin.webContents.send(ch, ...a); } catch {} };
const nativeHwnd = w => { try { const b = w.getNativeWindowHandle(); return b.length >= 8 ? String(b.readBigUInt64LE(0)) : String(b.readUInt32LE(0)); } catch { return ''; } };
const displayNow = () => { try { return screen.getDisplayNearestPoint(screen.getCursorScreenPoint()); } catch { return screen.getPrimaryDisplay(); } };

// ================= main window =================
function createWindow() {
  const st = store.read('settings', {});
  kiosk = !st.windowed;
  win = new BrowserWindow({
    width: 1280, height: 720, minWidth: 900, minHeight: 560,
    fullscreen: kiosk, kiosk, frame: !kiosk, backgroundColor: '#05060d', show: false, autoHideMenuBar: true,
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, webviewTag: true, backgroundThrottling: true }
  });
  win.loadFile(RENDERER('index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', e => e.preventDefault());
}
function comeBack() {
  if (!win || win.isDestroyed()) return;
  try {
    hideMusic(false); closeOverlay(false);
    if (win.isMinimized()) win.restore(); win.setKiosk(kiosk); win.setFullScreen(kiosk); win.show(); win.focus();
    if (helper) helper.focus(nativeHwnd(win));
    win.webContents.send('returned');
  } catch {}
}
function stepAside() { try { win.setAlwaysOnTop(false); win.setKiosk(false); win.setFullScreen(false); win.minimize(); } catch {} }

// web apps (SKchat inside <webview>); only our own site is allowed
app.on('web-contents-created', (_e, wc) => {
  wc.on('will-attach-webview', (ev, prefs, params) => {
    try { if (!SITE_HOSTS.includes(new URL(params.src).host)) { ev.preventDefault(); return; } } catch { ev.preventDefault(); return; }
    prefs.preload = path.join(__dirname, 'guestPreload.js'); prefs.nodeIntegration = false; prefs.contextIsolation = true; prefs.sandbox = true;
  });
});

// ================= storage =================
const STORES = ['apps', 'settings', 'stats'];
ipcMain.handle('store:get', (_e, n, d) => STORES.includes(n) ? store.read(n, d) : d);
ipcMain.handle('store:set', (_e, n, v) => { if (STORES.includes(n)) store.write(n, v); return true; });
ipcMain.handle('sys:info', () => ({ version: app.getVersion(), platform: process.platform, covers: COVER_DIR(), startup: isWin ? app.getLoginItemSettings().openAtLogin : false, helper: !!(helper && helper.ready) }));

// ================= accounts (profiles) =================
function dv(v) { if ('stringValue' in v) return v.stringValue; if ('integerValue' in v) return +v.integerValue; if ('doubleValue' in v) return v.doubleValue; if ('booleanValue' in v) return v.booleanValue; if ('arrayValue' in v) return (v.arrayValue.values || []).map(dv); if ('mapValue' in v) return df(v.mapValue.fields || {}); return null; }
const df = f => Object.fromEntries(Object.entries(f).map(([k, v]) => [k, dv(v)]));
async function fsGet(p, token) { const r = await fetch('https://firestore.googleapis.com/v1/projects/' + PROJECT + '/databases/(default)/documents/' + p, { headers: { Authorization: 'Bearer ' + token } }); if (!r.ok) return null; return df((await r.json()).fields || {}); }
async function signIn(u, p) {
  const r = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + API_KEY, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: u + '@users.sksmpmc.local', password: p, returnSecureToken: true }) });
  const j = await r.json();
  if (!r.ok) { const m = (j.error && j.error.message) || ''; throw new Error(/INVALID|NOT_FOUND|PASSWORD|USER_DISABLED/.test(m) ? 'Wrong username or password.' : 'Could not sign in. Check your internet connection.'); }
  return j;
}
async function loadProfile(u, p) {
  const a = await signIn(u, p);
  const d = (await fsGet('users/' + u, a.idToken)) || {}, m = (await fsGet('userData/' + u + '/music/state', a.idToken)) || {};
  if (d.banned) throw new Error('This account is banned.');
  return { u, nick: d.nick || '', bio: d.bio || '', av: typeof d.av === 'string' ? d.av : '', admin: !!d.isAdmin, stats: { playlists: (m.playlists || []).length, loved: (m.loved || []).length, history: (m.history || []).length } };
}
const enc = s => safeStorage.isEncryptionAvailable() ? 'e:' + safeStorage.encryptString(s).toString('base64') : 'p:' + Buffer.from(s).toString('base64');
const dec = s => s.startsWith('e:') ? safeStorage.decryptString(Buffer.from(s.slice(2), 'base64')) : Buffer.from(s.slice(2), 'base64').toString();
const readProfiles = () => store.read('profiles', []);
ipcMain.handle('auth:list', () => readProfiles().map(p => ({ ...p.meta })));
ipcMain.handle('auth:signin', async (_e, u, p) => {
  u = String(u || '').trim().toLowerCase();
  try { const meta = await loadProfile(u, p); const L = readProfiles().filter(x => x.meta.u !== u); L.push({ meta, pw: enc(p) }); store.write('profiles', L); return { ok: true, profile: meta }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('auth:refresh', async (_e, u) => { const L = readProfiles(), x = L.find(y => y.meta.u === u); if (!x) return null; try { x.meta = await loadProfile(u, dec(x.pw)); store.write('profiles', L); return x.meta; } catch { return x.meta; } });
ipcMain.handle('auth:cred', (_e, u) => { const x = readProfiles().find(y => y.meta.u === u); return x ? { u, p: dec(x.pw) } : null; });
ipcMain.handle('auth:remove', (_e, u) => { store.write('profiles', readProfiles().filter(x => x.meta.u !== u)); return true; });
function playersMeta() {
  const st = store.read('settings', {}), L = readProfiles();
  return [0, 1].map(i => { const u = (st.players || [])[i]; if (!u) return null; if (u === 'guest') return { u: 'guest', guest: true }; const p = L.find(x => x.meta.u === u); return p ? { ...p.meta } : { u }; });
}
function loginScript(u, p) { return '(function(u,p){var a=document.getElementById("li-u"),b=document.getElementById("li-p");if(a&&b&&a.offsetParent&&!window._sessOn){a.value=u;b.value=p;["input","change"].forEach(function(t){a.dispatchEvent(new Event(t,{bubbles:true}));b.dispatchEvent(new Event(t,{bubbles:true}));});if(window.doLogin)window.doLogin();}})(' + JSON.stringify(u) + ',' + JSON.stringify(p) + ')'; }
function autologin(wc, u) { const x = readProfiles().find(y => y.meta.u === u); if (!x) return; let p; try { p = dec(x.pw); } catch { return; } [1200, 3200, 6500].forEach(ms => setTimeout(() => { try { if (!wc.isDestroyed()) wc.executeJavaScript(loginScript(u, p)).catch(() => {}); } catch {} }, ms)); }

// ================= apps / covers =================
ipcMain.handle('dialog:file', async (_e, kind) => {
  const filters = kind === 'image' ? [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] : [{ name: 'Programs', extensions: ['exe', 'bat', 'cmd', 'lnk'] }, { name: 'All files', extensions: ['*'] }];
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
  return r.canceled ? null : r.filePaths[0];
});
const newCover = ext => path.join(COVER_DIR(), crypto.randomBytes(6).toString('hex') + (ext || '.jpg'));
// "fill" = portrait box art that fills the tile; "fit" = wide or square images shown whole on a blurred backdrop
function coverFit(file) { try { const z = nativeImage.createFromPath(file).getSize(); if (!z.width || !z.height) return 'fill'; return z.width / z.height <= 0.9 ? 'fill' : 'fit'; } catch { return 'fill'; } }
ipcMain.handle('cover:candidates', (_e, term) => covers.search(term).catch(() => []));
ipcMain.handle('cover:auto', async (_e, term) => { const dest = newCover('.jpg'); const r = await covers.auto(term, dest).catch(() => ({ ok: false })); return r.ok ? { ok: true, file: dest, fit: coverFit(dest), matched: r.matched, source: r.source } : { ok: false }; });
ipcMain.handle('cover:pick', async (_e, steamId) => { const dest = newCover('.jpg'); const r = await covers.download(steamId, dest).catch(() => ({ ok: false })); return r.ok ? { ok: true, file: dest, fit: coverFit(dest) } : { ok: false, error: r.error === 'offline' ? 'No internet connection.' : 'Could not download that one.' }; });
ipcMain.handle('cover:pickUrl', async (_e, url) => { const dest = newCover('.img'); const r = await covers.downloadUrl(String(url || '').trim(), dest); return r.ok ? { ok: true, file: dest, fit: coverFit(dest) } : { ok: false, error: r.error || 'Could not use that link.' }; });
ipcMain.handle('cover:copy', async (_e, src) => { try { const dest = newCover(path.extname(src) || '.jpg'); fs.mkdirSync(COVER_DIR(), { recursive: true }); fs.copyFileSync(src, dest); return { ok: true, file: dest, fit: coverFit(dest) }; } catch { return { ok: false }; } });
ipcMain.handle('cover:icon', async (_e, exe) => { try { if (!/^[a-z]:|^\\/i.test(exe)) return { ok: false }; const img = await app.getFileIcon(exe, { size: 'large' }); if (img.isEmpty()) return { ok: false }; const dest = newCover('.png'); fs.mkdirSync(COVER_DIR(), { recursive: true }); fs.writeFileSync(dest, img.toPNG()); return { ok: true, file: dest, fit: 'icon' }; } catch { return { ok: false }; } });
ipcMain.handle('cover:remove', (_e, f) => { try { if (f && path.dirname(f) === COVER_DIR()) fs.unlinkSync(f); } catch {} return true; });

// ================= running a game =================
const splitArgs = s => (String(s || '').match(/"[^"]*"|\S+/g) || []).map(x => x.replace(/^"|"$/g, ''));
function applyCompat(exe) { // old-game fixes: Windows compatibility flags for this one program (current user only)
  if (!isWin) return;
  execFile('reg', ['add', 'HKCU\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers', '/v', exe, '/t', 'REG_SZ', '/d', '~ WIN7RTM HIGHDPIAWARE DISABLEDXMAXIMIZEDWINDOWEDMODE', '/f'], { windowsHide: true }, () => {});
}
function showBackdrop(a) {
  closeBackdrop(); const d = win ? screen.getDisplayMatching(win.getBounds()) : screen.getPrimaryDisplay();
  backdrop = new BrowserWindow({ x: d.bounds.x, y: d.bounds.y, width: d.bounds.width, height: d.bounds.height, frame: false, backgroundColor: '#000000', show: false, skipTaskbar: true, focusable: false, movable: false, resizable: false, webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
  backdrop.loadFile(RENDERER('backdrop.html'), { query: { name: a.name || '', cover: a.cover || '' } });
  backdrop.once('ready-to-show', () => { try { backdrop.showInactive(); } catch {} });
  setTimeout(() => backdropFade(), 9000);
  backdrop.on('closed', () => { backdrop = null; });
}
function closeBackdrop() { try { if (backdrop && !backdrop.isDestroyed()) backdrop.destroy(); } catch {} backdrop = null; }
function gameState() { return game ? { id: game.id, name: game.name, startedAt: game.startedAt, cover: game.cover || '', hasWindow: !!game.hwnd } : null; }
const alive = p => { try { process.kill(p, 0); return true; } catch { return false; } };
const waitDead = async (pids, ms) => { const t = Date.now(); while (Date.now() - t < ms) { if (!pids.some(alive)) return true; await new Promise(r => setTimeout(r, 150)); } return false; };
const taskkill = pid => new Promise(res => execFile('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }, () => res()));
// Close politely first (so games can save), then force it. Returns true if we found something to close.
async function killGame() {
  if (!game || !isWin) return false;
  const pidsNow = () => [...new Set([game && game.pid, game && game.wpid].filter(x => x > 0))];
  let pids = pidsNow(), found = pids.length > 0 || !!game.hwnd;
  if (helper && helper.ready && game.hwnd) { helper.closeWindow(game.hwnd); if (pids.length) await waitDead(pids, 3000); else await new Promise(r => setTimeout(r, 1500)); }
  pids = pidsNow().filter(alive);
  await Promise.all(pids.map(taskkill));
  return found;
}
function statsTouch(id, ms) { if (!id) return; const st = store.read('stats', {}), x = st[id] || (st[id] = { last: 0, ms: 0, n: 0 }); x.last = Date.now(); if (ms) { x.ms += ms; x.best = Math.max(x.best || 0, ms); } else x.n++; store.write('stats', st); }
function endGame() {
  if (!game) return; try { statsTouch(game.id, Math.max(0, Date.now() - game.startedAt)); } catch {} game = null; closeBackdrop(); closeOverlay(false); if (helper) helper.unwatch();
  send('game:state', null); comeBack();
}
ipcMain.handle('game:state', () => gameState());
ipcMain.handle('stats:touch', (_e, id) => { statsTouch(String(id || '').slice(0, 60), 0); return true; });
ipcMain.handle('game:resume', () => { if (!game) return false; hideMusic(false); closeOverlay(false); stepAside(); if (helper && game.hwnd) helper.restore(game.hwnd); return true; });
ipcMain.handle('game:close', async () => { if (!game) return { ok: false }; const name = game.name, found = await killGame(); endGame(); return { ok: true, found, name }; });
ipcMain.handle('app:launch', async (_e, a) => {
  const target = String(a.exe || '').trim().replace(/^"|"$/g, '');
  if (!target) return { ok: false, error: 'No file set for this app.' };
  if (game && !a.replace) return { ok: false, error: game.name + ' is already running.', running: true };
  if (game && a.replace) { await killGame(); endGame(); await new Promise(r => setTimeout(r, 600)); }
  try {
    const isUrl = /^[a-z][a-z0-9+.-]*:\/\//i.test(target);
    if (!isUrl && !fs.existsSync(target)) return { ok: false, error: 'File not found: ' + target };
    game = { id: a.id, name: a.name || path.basename(target), exe: target, cover: a.cover || '', startedAt: Date.now(), pid: 0, wpid: 0, hwnd: '', mode: a.fs || 'auto', noWindow: false, exited: false };
    statsTouch(a.id, 0);
    if (a.compat && !isUrl && /\.exe$/i.test(target)) applyCompat(target);
    showBackdrop(game); send('game:state', gameState());
    let child = null;
    if (isUrl) await shell.openExternal(target);
    else if (/\.exe$/i.test(target)) {
      child = spawn(target, splitArgs(a.args), { cwd: path.dirname(target), detached: true, stdio: 'ignore' });
      game.pid = child.pid || 0;
      child.on('error', err => { const g = game; endGame(); win && win.webContents.send('launch-error', String(err.message || err)); });
      child.on('exit', () => { if (!game) return; game.exited = true; if (!helper || !helper.ready || game.noWindow) { if (Date.now() - game.startedAt > 15000) endGame(); } });
      child.unref();
    } else { const err = await shell.openPath(target); if (err) { endGame(); return { ok: false, error: err }; } }
    if (helper && helper.ready) helper.watch(game.pid, game.mode, process.pid);
    stepAside();
    return { ok: true };
  } catch (e) { endGame(); return { ok: false, error: String(e.message || e) }; }
});
function backdropFade() { try { if (backdrop && !backdrop.isDestroyed()) backdrop.webContents.executeJavaScript("document.body.classList.add('dim')").catch(() => {}); } catch {} }

// ================= helper (controller guide button, controller count, fullscreen) =================
const helperScript = () => path.join(__dirname, 'native', 'helper.ps1').replace('app.asar' + path.sep, 'app.asar.unpacked' + path.sep);
function startHelper() {
  if (!isWin) return;
  helper = new HelperClient({ script: helperScript() });
  helper.on('guide', (k, hwnd, pid, fsFlag) => {
    helperInfo.lastGuide = Date.now(); helperInfo.guides++; helperInfo.lastKey = k;
    fgTarget = hwnd && hwnd !== '0' && pid && pid !== process.pid ? { hwnd, pid, fs: !!fsFlag, at: Date.now() } : null;
    toggleOverlay();
  });
  helper.on('diag', l => { helperInfo.diag.push(l); if (helperInfo.diag.length > 12) helperInfo.diag.shift(); });
  helper.on('ready', () => { helperInfo.error = ''; if (overlayOpen) helper.padIn(true); });
  helper.on('padin', (slot, act) => {
    try { if (overlayWin && !overlayWin.isDestroyed() && (overlayOpen || overlayWin.isVisible())) overlayWin.webContents.send('padin', slot, act); else if (padTest) send('padtest', slot, act); } catch {}
  });
  helper.on('battery', (slot, type, level) => { batteries[slot] = { type, level }; send('battery', slot, type, level); });
  helper.on('pads', n => { padCount = n; send('pads', n); const pl = playersMeta(); if (n >= 2 && !pl[1] && game && !overlayOpen) openOverlay({ p2: true }); });
  helper.on('win', w => {
    if (!game) return; game.hwnd = w.hwnd; game.wpid = w.pid; send('game:state', gameState());
    if (isWin && store.read('settings', {}).boost && w.pid > 0 && game.boosted !== w.pid) { game.boosted = w.pid; execFile('powershell', ['-NoProfile', '-Command', '$p = Get-Process -Id ' + (w.pid | 0) + ' -ErrorAction SilentlyContinue; if ($p) { $p.PriorityClass = "High" }'], { windowsHide: true }, () => {}); }
  });
  helper.on('fs', t => { backdropFade(); if (game) game.fsOk = /^(already|borderless)/.test(String(t)); send('fs', t); });
  helper.on('gone', () => endGame());
  helper.on('nowin', () => { if (game) { game.noWindow = true; if (game.exited || !game.pid) endGame(); } });
  helper.on('error-line', l => { helperInfo.error = String(l).slice(0, 200); try { fs.appendFileSync(path.join(app.getPath('userData'), 'helper.log'), new Date().toISOString() + ' ' + l + '\n'); } catch {} });
  helper.start();
}

// ================= SK overlay (the "guide" menu) =================
// While a game runs, the menu is a full opaque page by default: this works with every kind of fullscreen, because a game in
// exclusive fullscreen simply minimizes when the menu takes focus. "Over the game" (see-through) is optional.
function wantOpaque() { const m = store.read('settings', {}).ovMode || 'auto'; if (m === 'over') return false; if (m === 'full') return true; return !!game; }
function ensureOverlay() {
  const opaque = wantOpaque();
  if (overlayWin && !overlayWin.isDestroyed()) { if (opaque === overlayOpaque) return overlayWin; const old = overlayWin; overlayWin = null; try { old.destroy(); } catch {} }
  overlayOpaque = opaque;
  const d = displayNow();
  overlayWin = new BrowserWindow({ x: d.bounds.x, y: d.bounds.y, width: d.bounds.width, height: d.bounds.height, transparent: !opaque, frame: false, show: false, skipTaskbar: true, hasShadow: false, resizable: false, movable: false, alwaysOnTop: true, backgroundColor: opaque ? '#05060d' : '#00000000', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, webviewTag: true, backgroundThrottling: false } });
  overlayWin.setAlwaysOnTop(true, 'screen-saver');
  overlayWin.loadFile(RENDERER('overlay.html'), { query: { opaque: opaque ? '1' : '' } });
  const mine = overlayWin;
  mine.on('closed', () => { if (overlayWin === mine) { overlayWin = null; overlayOpen = false; } });
  return overlayWin;
}
function overlayStateObj(opts) {
  return { game: gameState(), players: playersMeta(), apps: store.read('apps', []), settings: store.read('settings', {}), pads: padCount, music: !!(musicWin && !musicWin.isDestroyed()), opts: opts || {}, helper: !!(helper && helper.ready), covers: COVER_DIR(), stats: store.read('stats', {}), batteries, opaque: overlayOpaque, remote: remoteState() };
}
function openOverlay(opts) {
  const w = ensureOverlay(), d = displayNow(); try { w.setBounds(d.bounds); } catch {}
  overlayOpen = true; if (helper) helper.padIn(true);
  // Whatever fullscreen thing is in front (a game SKBox started, or any other): minimize it so even exclusive fullscreen lets go of the screen.
  overlayTarget = fgTarget && Date.now() - fgTarget.at < 1500 ? fgTarget : (game && game.hwnd ? { hwnd: String(game.hwnd), fs: true } : null); fgTarget = null;
  const moveAside = !!(overlayTarget && overlayTarget.fs && overlayOpaque && helper && helper.ready);
  if (moveAside) helper.minimize(overlayTarget.hwnd);
  const show = () => { try { w.setAlwaysOnTop(true, 'screen-saver'); w.show(); w.moveTop(); w.focus(); if (helper) helper.focus(nativeHwnd(w)); w.webContents.send('overlay:open', overlayStateObj(opts)); } catch {} };
  const go = () => { if (w.webContents.isLoading()) w.webContents.once('did-finish-load', show); else show(); };
  if (moveAside) setTimeout(go, 220); else go();
}
function closeOverlay(refocus) {
  if (helper) helper.padIn(padTest);
  if (!overlayWin || overlayWin.isDestroyed()) { overlayOpen = false; return; }
  if (!overlayOpen && !overlayWin.isVisible()) return;
  overlayOpen = false; try { overlayWin.webContents.send('overlay:close'); overlayWin.hide(); } catch {}
  const tgt = overlayTarget; overlayTarget = null;
  if (refocus) { if (musicVisible && musicWin && !musicWin.isDestroyed()) { musicWin.focus(); if (helper) helper.focus(nativeHwnd(musicWin)); } else if (tgt && helper && helper.ready) helper.restore(tgt.hwnd); else if (game && game.hwnd && helper) helper.focus(game.hwnd); }
}
let overlayStamp = 0;
// Both the native helper and the browser can see the same Xbox / PS press; ignore the second one.
function toggleOverlay() { if (Date.now() - overlayStamp < 700) return; overlayStamp = Date.now(); if (overlayOpen) closeOverlay(true); else openOverlay({}); }
ipcMain.handle('overlay:state', () => overlayStateObj({}));
ipcMain.handle('overlay:close', (_e, refocus) => { closeOverlay(refocus !== false); return true; });
ipcMain.handle('overlay:home', () => { closeOverlay(false); hideMusic(false); comeBack(); return true; });
ipcMain.handle('overlay:setPlayer', (_e, slot, u) => {
  const st = store.read('settings', {}); st.players = st.players || [null, null]; st.players[slot === 1 ? 1 : 0] = u || null; store.write('settings', st); send('players-changed'); return true;
});
async function takeShot(notify) {
  try {
    const wasOpen = overlayOpen, giveBack = wasOpen && overlayOpaque && !!game;
    if (giveBack) { closeOverlay(true); await new Promise(r => setTimeout(r, 1600)); } else { if (wasOpen && overlayWin) overlayWin.hide(); await new Promise(r => setTimeout(r, 350)); }
    const d = displayNow(), srcs = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: d.size.width * d.scaleFactor, height: d.size.height * d.scaleFactor } });
    const s = srcs.find(x => String(x.display_id) === String(d.id)) || srcs[0];
    const dir = path.join(app.getPath('pictures'), 'SKBox'); fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, (game ? game.name.replace(/[^\w\- ]+/g, '') + ' ' : 'SKBox ') + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.png');
    fs.writeFileSync(file, s.thumbnail.toPNG());
    if (giveBack || notify) { try { new Notification({ title: 'Screenshot saved', body: 'Pictures\\SKBox', silent: true }).show(); } catch {} }
    else if (wasOpen && overlayWin) { overlayWin.show(); overlayWin.focus(); }
    return { ok: true, file };
  } catch (e) { return { ok: false, error: String(e.message || e) }; }
}
ipcMain.handle('overlay:screenshot', () => takeShot(false));

// ================= music host (SKMusic keeps playing while you game) =================
function ensureMusic(u) {
  if (musicWin && !musicWin.isDestroyed() && musicUser === u) return musicWin;
  if (musicWin && !musicWin.isDestroyed()) musicWin.destroy();
  musicUser = u || 'guest';
  musicWin = new BrowserWindow({ show: false, frame: false, backgroundColor: '#000000', skipTaskbar: true, webPreferences: { partition: 'persist:skbox-' + musicUser, preload: path.join(__dirname, 'guestPreload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false } });
  musicWin.loadURL(SITE + '/skmusic');
  musicWin.webContents.on('did-finish-load', () => { if (musicUser !== 'guest') autologin(musicWin.webContents, musicUser); });
  musicWin.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  musicWin.on('closed', () => { musicWin = null; musicVisible = false; });
  return musicWin;
}
function showMusic(u) {
  const w = ensureMusic(u); closeOverlay(false); musicVisible = true; send('music:visible', true);
  try { w.setFullScreen(true); w.show(); w.focus(); if (helper) helper.focus(nativeHwnd(w)); } catch {}
}
function hideMusic(refocus) {
  if (!musicWin || musicWin.isDestroyed() || !musicVisible) { musicVisible = false; return; }
  musicVisible = false; send('music:visible', false); try { musicWin.setFullScreen(false); musicWin.hide(); } catch {}
  if (refocus) { if (game && game.hwnd && helper && !win.isVisible()) helper.focus(game.hwnd); else comeBack(); }
}
const MUSIC = { toggle: 'SKMusic.playPause()', next: 'SKMusic.next()', prev: 'SKMusic.prev()', daily: 'SKMusic.dailyMix()', stop: 'SKMusic.stopRadio()',
  volup: '(function(){var s=SKMusic.state();SKMusic.setVol(Math.min(100,(s.vol==null?80:s.vol)+10))})()', voldown: '(function(){var s=SKMusic.state();SKMusic.setVol(Math.max(0,(s.vol==null?80:s.vol)-10))})()' };
ipcMain.handle('music:open', (_e, u) => { showMusic(u || 'guest'); return true; });
ipcMain.handle('music:ensure', (_e, u) => { ensureMusic(u || 'guest'); return true; });
ipcMain.handle('music:status', async () => {
  if (!musicWin || musicWin.isDestroyed()) return { ready: false };
  try { const s = await musicWin.webContents.executeJavaScript('(window.SKMusic&&SKMusic.state)?JSON.stringify(SKMusic.state()):null'); return s ? { ready: true, ...JSON.parse(s) } : { ready: false }; } catch { return { ready: false }; }
});
ipcMain.handle('music:cmd', async (_e, c, arg) => {
  if (!musicWin || musicWin.isDestroyed()) return false;
  let js = MUSIC[c]; if (c === 'radio') js = 'SKMusic.startRadio("genre",' + JSON.stringify(String(arg || '').slice(0, 30)) + ')';
  if (!js) return false; try { await musicWin.webContents.executeJavaScript('(function(){try{' + js + '}catch(e){}})()'); return true; } catch { return false; }
});
ipcMain.on('guest:home', e => { if (musicWin && !musicWin.isDestroyed() && e.sender === musicWin.webContents) hideMusic(true); });
ipcMain.on('guest:osk', (e, o) => { if (musicWin && !musicWin.isDestroyed() && e.sender === musicWin.webContents) openOverlay({ osk: { value: (o && o.value) || '', target: 'music' } }); });
ipcMain.handle('overlay:osk-result', (_e, r) => {
  closeOverlay(false);
  if (r && r.target === 'music' && musicWin && !musicWin.isDestroyed()) {
    if (!r.cancel) musicWin.webContents.executeJavaScript('(function(t,s){var e=document.activeElement;if(!e)return;if(e.isContentEditable){e.textContent=t;e.dispatchEvent(new Event("input",{bubbles:true}));}else{var pr=e.tagName==="TEXTAREA"?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,ds=Object.getOwnPropertyDescriptor(pr,"value");if(ds&&ds.set)ds.set.call(e,t);else e.value=t;e.dispatchEvent(new Event("input",{bubbles:true}));}if(s){e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:true}));}})(' + JSON.stringify(String(r.text || '')) + ',' + (r.send ? 'true' : 'false') + ')').catch(() => {});
    musicWin.focus(); if (helper) helper.focus(nativeHwnd(musicWin));
  } else if (game && game.hwnd && helper) helper.focus(game.hwnd);
  return true;
});

// ================= Xbox button: take it back from Game Bar =================
// Windows opens Xbox Game Bar when you press the controller's Xbox button, and then SKBox never sees it.
// This turns off just that one shortcut (Windows Settings > Gaming > Xbox Game Bar) for the current user.
function takeGuide(on) { if (!isWin) return; for (const v of ['UseNexusForGameBarEnabled', 'GamepadNexusChordEnabled']) execFile('reg', ['add', 'HKCU\\Software\\Microsoft\\GameBar', '/v', v, '/t', 'REG_DWORD', '/d', on ? '0' : '1', '/f'], { windowsHide: true }, () => {}); }
ipcMain.handle('helper:status', () => ({ ready: !!(helper && helper.ready), error: helperInfo.error, lastGuide: helperInfo.lastGuide, guides: helperInfo.guides, lastKey: helperInfo.lastKey, diag: helperInfo.diag.slice(), pads: padCount, batteries, ovMode: store.read('settings', {}).ovMode || 'auto', takeGuide: store.read('settings', {}).takeGuide !== false }));
ipcMain.handle('helper:padTest', (_e, on) => { padTest = !!on; if (helper) helper.padIn(padTest || overlayOpen); return padTest; });
ipcMain.handle('helper:testMenu', () => { if (!overlayOpen) toggleOverlay(); return true; });
ipcMain.handle('sys:takeGuide', (_e, on) => { const s = store.read('settings', {}); s.takeGuide = !!on; store.write('settings', s); takeGuide(!!on); return !!on; });

// ================= performance stats, sleep timer, backup =================
let lastCpu = null;
function cpuPct() { let idle = 0, tot = 0; os.cpus().forEach(c => { for (const k in c.times) tot += c.times[k]; idle += c.times.idle; }); const r = lastCpu ? 1 - (idle - lastCpu.idle) / Math.max(1, tot - lastCpu.tot) : 0; lastCpu = { idle, tot }; return Math.round(Math.max(0, Math.min(1, r)) * 100); }
ipcMain.handle('sys:stats', () => ({ cpu: cpuPct(), ramUsed: os.totalmem() - os.freemem(), ramTotal: os.totalmem() }));
let sleepT = null;
async function fireTimer() {
  const a = sleepT && sleepT.action; sleepT = null; send('timer:fired', a);
  try { new Notification({ title: 'SKBox timer', body: a === 'closegame' ? 'Closing your game.' : a === 'shutdown' ? 'Shutting down.' : 'Going to sleep.' }).show(); } catch {}
  if (a === 'closegame') { if (game) { await killGame(); endGame(); } } else if (POWER[a] && isWin) setTimeout(() => execFile(POWER[a][0], POWER[a][1], { windowsHide: true }, () => {}), 4000);
}
const timerInfo = () => sleepT ? { at: sleepT.at, action: sleepT.action } : null;
ipcMain.handle('timer:get', () => timerInfo());
ipcMain.handle('timer:set', (_e, min, action) => {
  if (sleepT) { clearTimeout(sleepT.h); sleepT = null; }
  min = Math.round(Number(min) || 0); if (min < 1 || min > 600 || !['sleep', 'shutdown', 'closegame'].includes(action)) return null;
  sleepT = { at: Date.now() + min * 60000, action, h: setTimeout(fireTimer, min * 60000) }; return timerInfo();
});
ipcMain.handle('backup:export', async () => {
  try {
    const r = await dialog.showSaveDialog(win, { title: 'Save SKBox backup', defaultPath: path.join(app.getPath('documents'), 'SKBox-backup-' + new Date().toISOString().slice(0, 10) + '.json'), filters: [{ name: 'SKBox backup', extensions: ['json'] }] });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    fs.writeFileSync(r.filePath, JSON.stringify({ skbox: 1, version: app.getVersion(), settings: store.read('settings', {}), apps: store.read('apps', []), stats: store.read('stats', {}) }, null, 2));
    return { ok: true, file: r.filePath };
  } catch (e) { return { ok: false, error: String(e.message || e) }; }
});
ipcMain.handle('backup:import', async () => {
  try {
    const r = await dialog.showOpenDialog(win, { title: 'Open SKBox backup', properties: ['openFile'], filters: [{ name: 'SKBox backup', extensions: ['json'] }] });
    if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
    const raw = fs.readFileSync(r.filePaths[0], 'utf8'); if (raw.length > 5e6) return { ok: false, error: 'That file is too big to be an SKBox backup.' };
    const d = JSON.parse(raw);
    if (!d || d.skbox !== 1 || !d.settings || typeof d.settings !== 'object' || Array.isArray(d.settings) || !Array.isArray(d.apps)) return { ok: false, error: 'That file is not an SKBox backup.' };
    const apps = d.apps.filter(a => a && typeof a === 'object' && typeof a.id === 'string' && typeof a.name === 'string' && typeof a.exe === 'string').slice(0, 500);
    const stats = d.stats && typeof d.stats === 'object' && !Array.isArray(d.stats) ? d.stats : {};
    store.write('settings', d.settings); store.write('apps', apps); store.write('stats', stats);
    setTimeout(() => { try { win.webContents.reload(); } catch {} }, 400);
    return { ok: true, apps: apps.length };
  } catch (e) { return { ok: false, error: 'Could not read that file.' }; }
});

// ================= screenshots =================
const shotDir = () => path.join(app.getPath('pictures'), 'SKBox');
ipcMain.handle('shots:list', () => { try { return fs.readdirSync(shotDir()).filter(f => /\.png$/i.test(f)).map(f => { const p = path.join(shotDir(), f); return { file: p, name: f.replace(/\.png$/i, ''), t: fs.statSync(p).mtimeMs }; }).sort((a, b) => b.t - a.t).slice(0, 60); } catch { return []; } });
ipcMain.handle('shots:delete', (_e, f) => { try { if (f && path.dirname(f) === shotDir() && /\.png$/i.test(f)) { fs.unlinkSync(f); return true; } } catch {} return false; });
ipcMain.handle('shots:folder', () => { try { fs.mkdirSync(shotDir(), { recursive: true }); shell.openPath(shotDir()); return true; } catch { return false; } });

// ================= Bluetooth (inside SKBox) =================
const btScript = () => path.join(__dirname, 'native', 'bluetooth.ps1').replace('app.asar' + path.sep, 'app.asar.unpacked' + path.sep);
let btBusy = false;
ipcMain.handle('bt:run', async (_e, action, id) => {
  if (!['list', 'scan', 'pair', 'unpair'].includes(action)) return { ok: false, error: 'Unknown action.' };
  if (btBusy) return { ok: false, error: 'Bluetooth is busy. Wait a moment.' };
  btBusy = true; try { return await bt.run(btScript(), action, id ? String(id) : '', { timeout: action === 'scan' ? 100000 : 90000 }); } finally { btBusy = false; }
});

// ================= wifi / system =================
ipcMain.handle('wifi:scan', async () => { try { return { ok: true, nets: await wifi.scan() }; } catch (e) { return { ok: false, error: 'Wi-Fi is not available on this PC.' }; } });
ipcMain.handle('wifi:status', async () => { try { return await wifi.status(); } catch { return { connected: false, ssid: '', signal: 0 }; } });
ipcMain.handle('wifi:connect', async (_e, a) => { try { return await wifi.connect(a.ssid, a.password || '', a.auth || ''); } catch (e) { return { ok: false, error: 'Could not connect.' }; } });
ipcMain.handle('wifi:disconnect', () => wifi.disconnect());
const POWER = { shutdown: ['shutdown', ['/s', '/t', '0']], restart: ['shutdown', ['/r', '/t', '0']], logoff: ['shutdown', ['/l']], sleep: ['rundll32.exe', ['powrprof.dll,SetSuspendState', '0,1,0']] };
ipcMain.handle('sys:power', (_e, what) => { if (what === 'quit') { app.quit(); return true; } const p = POWER[what]; if (p && isWin) execFile(p[0], p[1], { windowsHide: true }, () => {}); return !!p; });
ipcMain.handle('sys:openSettings', (_e, page) => { const ok = { bluetooth: 'ms-settings:bluetooth', sound: 'ms-settings:sound', wifi: 'ms-settings:network-wifi', devices: 'ms-settings:connecteddevices' }[page]; if (!ok) return false; stepAside(); shell.openExternal(ok); try { new Notification({ title: 'SKBox is still running', body: 'Press Ctrl+Shift+B or use the tray icon to come back.', silent: true }).show(); } catch {} return true; });
ipcMain.handle('sys:volume', (_e, dir) => { if (!isWin) return false; const k = { up: 175, down: 174, mute: 173 }[dir]; if (!k) return false; execFile('powershell', ['-NoProfile', '-Command', '(New-Object -ComObject WScript.Shell).SendKeys([char]' + k + ')'], { windowsHide: true }, () => {}); return true; });
ipcMain.handle('sys:startup', (_e, on) => { if (isWin || process.platform === 'darwin') app.setLoginItemSettings({ openAtLogin: !!on }); const s = store.read('settings', {}); s.startup = !!on; store.write('settings', s); return !!on; });
ipcMain.handle('sys:kiosk', (_e, on) => { kiosk = !!on; const s = store.read('settings', {}); s.windowed = !on; store.write('settings', s); try { win.setKiosk(kiosk); win.setFullScreen(kiosk); } catch {} return kiosk; });

// ================= Remote play (host) =================
// Off until the user turns it on in Settings > Remote play. While off there is no server, no open port and no broadcast reply.
let remote = null, remoteWin = null, remoteLoaded = null, remoteStats = null, mapper = null, mapperT = null, inCount = 0, inWindow = 0;
const answers = {};
let remoteSrc = 'screen', lastDisp = null, fixStage = 0, badCount = 0, fixBusy = false, fixTold = false, modeTick = 0, fixGame = '';
const remoteDisplay = () => { try { if (win && !win.isDestroyed() && win.isVisible() && !win.isMinimized()) { lastDisp = screen.getDisplayMatching(win.getBounds()); return lastDisp; } } catch {} return lastDisp || screen.getPrimaryDisplay(); };
setInterval(() => { try { if (win && !win.isDestroyed() && win.isVisible() && !win.isMinimized()) lastDisp = screen.getDisplayMatching(win.getBounds()); } catch {} }, 1500);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const REMOTE_DIR = () => path.join(__dirname, '..', 'renderer', 'remote');
const rset = () => { const s = store.read('settings', {}); return { quality: ['smooth', 'low', 'balanced', 'high'].includes(s.remoteQuality) ? s.remoteQuality : 'smooth', autoFix: s.remoteAutoFix !== false, allowInput: s.remoteInput !== false, padMode: ['menus', 'keys', 'off'].includes(s.remotePad) ? s.remotePad : 'menus' }; };
const remoteState = () => Object.assign(remote ? remote.state() : { on: false, port: 0, pin: '', ips: [], client: null }, { stats: remoteStats, cfg: rset(), helper: !!(helper && helper.ready), supported: isWin });
const pushRemote = () => send('remote:state', remoteState());
const hin = line => { if (helper && helper.ready) helper.send(line); };
function ensureRemoteWin() {
  if (remoteWin && !remoteWin.isDestroyed()) return remoteLoaded;
  const ses = session.fromPartition('skremote');
  ses.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'media' || perm === 'display-capture'));
  ses.setDisplayMediaRequestHandler(async (_req, cb) => {
    try {
      // Streams the screen SKBox is on (not wherever the mouse happens to be). If a game hides from screen capture,
      // the auto-fix switches to capturing the game window itself.
      if (remoteSrc === 'window' && game && game.hwnd) { const ws = await desktopCapturer.getSources({ types: ['window'] }); const w = ws.find(x => String(x.id).split(':')[1] === String(game.hwnd)); if (w) { cb({ video: w, audio: 'loopback' }); return; } }
      const d = remoteDisplay(), srcs = await desktopCapturer.getSources({ types: ['screen'] }); const s0 = srcs.find(x => String(x.display_id) === String(d.id)) || (srcs.length > 1 ? srcs.find(x => String(x.display_id) === String(screen.getPrimaryDisplay().id)) : null) || srcs[0]; cb(s0 ? { video: s0, audio: 'loopback' } : {});
    } catch { cb({}); }
  });
  remoteWin = new BrowserWindow({ show: false, width: 320, height: 240, webPreferences: { preload: path.join(__dirname, 'remotePreload.js'), partition: 'skremote', contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false } });
  remoteWin.on('closed', () => { remoteWin = null; remoteLoaded = null; });
  remoteLoaded = new Promise(res => remoteWin.webContents.once('did-finish-load', res)); remoteWin.loadFile(path.join(REMOTE_DIR(), 'host.html'));
  return remoteLoaded;
}
function startMapper() {
  stopMapper();
  mapper = new PadMapper({ key: (sc, ext, d) => hin('IK ' + sc + ' ' + ext + ' ' + d), mouse: (dx, dy) => hin('IM ' + dx + ' ' + dy), button: (b, d) => hin('IB ' + b + ' ' + d) });
  mapper.setMode(rset().padMode); mapperT = setInterval(() => { try { mapper && mapper.tick(Date.now()); } catch {} }, 16);
}
function stopMapper() { clearInterval(mapperT); mapperT = null; if (mapper) { try { mapper.reset(); } catch {} mapper = null; } }
async function remoteCreateSession({ sid, name, offer }) {
  remoteDisplay(); remoteSrc = 'screen'; fixStage = 0; badCount = 0; fixTold = false; modeTick = 0;
  await ensureRemoteWin(); const cfg = rset();
  const p = new Promise((resolve, reject) => { const t = setTimeout(() => { delete answers[sid]; reject(new Error('The PC took too long to start the stream.')); }, 20000); answers[sid] = { resolve: d => { clearTimeout(t); delete answers[sid]; d && d.error ? reject(new Error(d.error)) : resolve(d); } }; });
  remoteWin.webContents.executeJavaScript('window.__skhostOffer(' + JSON.stringify({ sid, offer, cfg }) + ')', true).catch(() => {});
  const ans = await p; startMapper(); remoteStats = null;
  try { new Notification({ title: 'Remote play', body: name + ' connected to SKBox' }).show(); } catch {}
  return ans;
}
const toClient = o => { try { if (remoteWin && !remoteWin.isDestroyed()) remoteWin.webContents.send('remote:toClient', JSON.stringify(o)); } catch {} };
let frozenCount = 0, frozenTold = false;
const recapture = () => (remoteWin && !remoteWin.isDestroyed() ? remoteWin.webContents.executeJavaScript('window.__skhostRecap && window.__skhostRecap()', true).catch(() => false) : Promise.resolve(false));
// Black or frozen picture while a game runs. Steps: capture the game window instead of the screen, then take the game out of
// exclusive fullscreen and capture the screen again, then try the window again, then tell the player what to change in the game.
async function remoteLadder() {
  if (fixBusy || !game) return; fixBusy = true; badCount = 0;
  try {
    if (fixStage === 0) { fixStage = 1; remoteSrc = 'window'; toClient({ t: 'notice', text: 'Fixing the picture (step 1)\u2026' }); await recapture(); }
    else if (fixStage === 1) { fixStage = 2; remoteSrc = 'screen'; toClient({ t: 'notice', text: 'Fixing the picture (step 2)\u2026 leaving exclusive fullscreen.' }); if (helper && helper.ready) helper.fixFullscreen(game && game.hwnd ? game.hwnd : 0); await sleep(3800); await recapture(); }
    else if (fixStage === 2) { fixStage = 3; remoteSrc = 'window'; toClient({ t: 'notice', text: 'Fixing the picture (step 3)\u2026' }); await recapture(); }
    else if (!fixTold) { fixTold = true; toClient({ t: 'notice', text: 'Still black. In the game\u2019s video settings, set Display mode to Borderless or Windowed.' }); }
  } finally { fixBusy = false; }
}
function remoteFixFs() {   // manual: same ladder, from the SKBox menu
  if (!game) { toClient({ t: 'notice', text: 'No game is running.' }); return; }
  fixStage = Math.min(fixStage, 1); fixTold = false; remoteLadder();
}
function remoteEndSession() {
  frozenCount = 0; frozenTold = false; fixStage = 0; badCount = 0; remoteSrc = 'screen'; stopMapper(); remoteStats = null; hin('IR');
  try { if (remoteWin && !remoteWin.isDestroyed()) remoteWin.webContents.send('remote:kick'); } catch {}
}
function remoteInit() {
  if (remote) return remote;
  remote = new RemoteHost({ name: os.hostname(), version: app.getVersion(), webDir: REMOTE_DIR(), createSession: remoteCreateSession, endSession: () => remoteEndSession() });
  remote.on('state', pushRemote);
  remote.on('ended', (c, why) => { try { new Notification({ title: 'Remote play', body: (c && c.name ? c.name + ' disconnected' : 'Disconnected') }).show(); } catch {} });
  return remote;
}
ipcMain.handle('remote:state', () => remoteState());
ipcMain.handle('remote:set', async (_e, on) => {
  if (!isWin) return { ok: false, error: 'Remote play host needs Windows.' };
  try {
    if (on) await remoteInit().start(); else { if (remote) remote.stop(); if (remoteWin && !remoteWin.isDestroyed()) { try { remoteWin.destroy(); } catch {} } remoteWin = null; remoteLoaded = null; }
    pushRemote(); return { ok: true, state: remoteState() };
  } catch (e) { return { ok: false, error: String(e.message || e) }; }
});
ipcMain.handle('remote:pin', () => { if (remote && remote.on_) remote.newPin(); return remoteState(); });
ipcMain.handle('remote:fix', () => { remoteFixFs(); return true; });
ipcMain.handle('remote:kick', () => { if (remote) remote.endSession('Disconnected from SKBox'); return remoteState(); });
ipcMain.handle('remote:cfg', (_e, patch) => {
  const s = store.read('settings', {}); patch = patch || {};
  if (['smooth', 'low', 'balanced', 'high'].includes(patch.quality)) s.remoteQuality = patch.quality;
  if (typeof patch.autoFix === 'boolean') s.remoteAutoFix = patch.autoFix;
  if (typeof patch.allowInput === 'boolean') s.remoteInput = patch.allowInput;
  if (['menus', 'keys', 'off'].includes(patch.padMode)) { s.remotePad = patch.padMode; if (mapper) mapper.setMode(patch.padMode); }
  store.write('settings', s); pushRemote(); return remoteState();
});
const fromRemoteWin = e => remoteWin && !remoteWin.isDestroyed() && e.sender === remoteWin.webContents;
ipcMain.on('remote:answer', (e, sid, d) => { if (fromRemoteWin(e) && answers[sid]) answers[sid].resolve(d); });
ipcMain.on('remote:ended', (e, sid) => { if (fromRemoteWin(e) && remote) remote.sessionEnded(sid); });
ipcMain.on('remote:stats', (e, st) => { if (!fromRemoteWin(e) || !st || typeof st !== 'object') return;
  if (game && fixGame !== game.id) { fixGame = game.id; fixStage = 0; fixTold = false; remoteSrc = 'screen'; }
  const bad = !!game && !fixBusy && (st.black || ((st.fps | 0) <= 1 && (st.kbps | 0) < 150));
  if (bad) { if (++badCount >= 4) { if (rset().autoFix) remoteLadder(); else if (!frozenTold) { frozenTold = true; toClient({ t: 'notice', text: 'Picture black or frozen? Turn on \u201CFix fullscreen games automatically\u201D in SKBox Remote play settings.' }); } badCount = 0; } } else if (!fixBusy) badCount = 0;
  if (++modeTick % 3 === 1) toClient({ t: 'mode', game: !!game });
  remoteStats = { fps: st.fps | 0, kbps: st.kbps | 0, rtt: st.rtt | 0, codec: String(st.codec || '').slice(0, 12), w: st.w | 0, h: st.h | 0, limit: String(st.limit || '').slice(0, 12), hw: !!st.hw }; pushRemote(); });
ipcMain.on('remote:input', (e, raw) => {
  if (!fromRemoteWin(e) || !remote || !remote.session || remote.session.pending || typeof raw !== 'string' || raw.length > 600) return;
  const cfg = rset(); if (!cfg.allowInput || !helper || !helper.ready) return;
  const now = Date.now(); if (now - inWindow > 1000) { inWindow = now; inCount = 0; } if (++inCount > 3000) return;   // flood guard
  let m; try { m = JSON.parse(raw); } catch { return; } if (!m || typeof m.t !== 'string') return;
  const I = v => Math.round(+v) || 0, cl = (v, a, b) => Math.max(a, Math.min(b, I(v)));
  switch (m.t) {
    case 'ma': hin('IA ' + cl(+m.x * 65535, 0, 65535) + ' ' + cl(+m.y * 65535, 0, 65535)); break;
    case 'mm': hin('IM ' + cl(m.dx, -2000, 2000) + ' ' + cl(m.dy, -2000, 2000)); break;
    case 'mb': hin('IB ' + cl(m.b, 0, 4) + ' ' + (m.d ? 1 : 0)); break;
    case 'mw': hin('IW ' + cl(m.dy, -2400, 2400)); break;
    case 'mh': hin('IH ' + cl(m.dx, -2400, 2400)); break;
    case 'k': { const sc = I(m.sc); if (sc > 0 && sc < 0x80) hin('IK ' + sc + ' ' + (m.ext ? 1 : 0) + ' ' + (m.d ? 1 : 0)); break; }
    case 'ra': hin('IR'); if (mapper) mapper.reset(); break;
    case 'fixfs': remoteFixFs(); break;
    case 'p': if (mapper && cfg.padMode !== 'off') mapper.frame(m); break;
  }
});
app.on('before-quit', () => { try { remote && remote.stop(); } catch {} });

// ================= tray, shortcuts, updates =================
function setupTray() {
  try {
    const img = nativeImage.createFromPath(path.join(__dirname, '..', 'build', 'icon.png')).resize({ width: 20, height: 20 });
    tray = new Tray(img); tray.setToolTip('SKBox');
    tray.setContextMenu(Menu.buildFromTemplate([{ label: 'Open SKBox', click: comeBack }, { label: 'Open the SK menu', click: () => openOverlay({}) }, { label: 'Exit SKBox', click: () => app.quit() }]));
    tray.on('click', comeBack);
  } catch {}
}
function setupUpdates() {
  if (!app.isPackaged) return;
  try {
    const { autoUpdater } = require('electron-updater');
    autoUpdater.autoDownload = true; autoUpdater.autoInstallOnAppQuit = true;
    autoUpdater.on('update-downloaded', i => send('update-ready', i.version)); autoUpdater.on('error', () => {});
    autoUpdater.checkForUpdates().catch(() => {}); setInterval(() => autoUpdater.checkForUpdates().catch(() => {}), 3 * 3600 * 1000);
    ipcMain.handle('update:install', () => { autoUpdater.quitAndInstall(); return true; });
  } catch {}
}
app.on('second-instance', comeBack);
app.commandLine.appendSwitch('disable-features', 'WebRtcHideLocalIpsWithMdns');
app.whenReady().then(() => {
  const st = store.read('settings', {});
  if (st.startup === undefined && (isWin || process.platform === 'darwin')) { app.setLoginItemSettings({ openAtLogin: true }); st.startup = true; store.write('settings', st); }
  if (st.takeGuide !== false) takeGuide(true);
  createWindow(); setupTray(); setupUpdates(); startHelper();
  globalShortcut.register('Control+Shift+B', comeBack);
  globalShortcut.register('Control+Shift+O', toggleOverlay);
  globalShortcut.register('Control+Shift+S', () => { takeShot(true); });
});
app.on('will-quit', () => { globalShortcut.unregisterAll(); try { helper && helper.stop(); } catch {} });
app.on('window-all-closed', () => app.quit());
