# SKBox

A console-style media center for Windows. Starts with your PC, runs fullscreen, works with controllers.

## What's new in 1.8.0
- **Press A to start.** SKBox opens on a clock screen; press A (or the PlayStation cross), then pick Player 1's profile. Turn this off in Settings > Preferences > "Ask who is playing at startup".
- **SK menu works with the controller.** The menu window never read the controller itself, so only the mouse worked. Fixed.
- **Player highlight is at the top.** A small bar under the P1 / P2 chip shows who is using a controller. Tiles no longer get tags.
- **Fancy idle screen**: a big clock with a seconds ring, drifting colors and soft music that changes with the time of day. Settings > Preferences: when it starts, style, its music, and "Show the idle screen now".
- **More looks and sound**: 7 new themes (Sunset, Ocean, Forest, Rose, Cyber, Graphite, Sakura), 6 new wallpapers, 6 more accent colors, and 7 new music moods (Dreamy Clouds, Deep Space, Ocean Calm, Forest Morning, Late Night Jazz, Arcade Chill, Twilight Clock).
- **Remote play**: streams the monitor SKBox is on, fixes exclusive-fullscreen black screens by itself, defaults to 720p 60 for less delay, and the "Click to start" box is gone. Disconnect, Fix picture and Quality moved into the SK menu.

## What's in it
- Home screen with the apps you pinned, a clock, Wi-Fi and Bluetooth buttons and your profiles (PS5 / Steam Big Picture style)
- **Library**: every app and game lives here (SKchat and SKMusic too). Press X on an app to pin it to Home or unpin it. Sort with LB / RB (A–Z, recently played, most played), search, and see how long you have played each game
- Bluetooth right inside SKBox: pair and forget controllers, headphones and speakers without opening Windows settings
- Profiles are your SKchat accounts: sign in once, SKchat and SKMusic open already logged in
- 2 players: Player 1 uses controller 1, Player 2 presses Start on controller 2 to join and picks their own profile
- SKchat and SKMusic are built-in apps (the left stick moves a cursor, A clicks, B goes back, View/Select returns to SKBox)
- Add your own apps: type a name and a path like C:\Games\game.exe (or a link like steam://rungameid/12345). Cover art is found automatically (Steam first, then Wikipedia for older games). If nothing is found, a picker opens so you can search again with another name, paste an image link, or use your own picture. You can change it any time with Y on the tile > Change cover art
- Settings: Wi-Fi (scan and connect with the on-screen keyboard), controllers, players, apps, accent color, startup, sound, Bluetooth, power
- Cozy mode: 8 wallpapers, 24 profile pictures (Wild West, Blocky World, Neon City and Cozy packs), soft UI sounds, five generated music moods (Campfire, Rainy Lo-fi, Wild West Dusk, Pixel Garden, Neon Night) and slow floating sparkles. Picking a wallpaper picks matching music
- Updates itself from GitHub Releases

## Games: fullscreen and the SK menu
**Fullscreen, done for you.** When you start a game, SKBox puts a black screen behind it (with the cover art while it loads), finds the game's window and makes it fullscreen. This is also how older games such as the first Assassin's Creed get fullscreen without you fiddling. Each app has a Fullscreen choice (Edit app):
- Auto (recommended): fills the screen, or keeps the game's shape with black bars when it is not widescreen
- Fill the screen / Keep shape (black bars)
- Press Alt+Enter or Press F11, for games that only go fullscreen with that key (falls back to Auto if it does not work)
- Leave it alone
Turn on **Old game fixes** for very old games. It applies Windows compatibility settings to that one program (Windows 7 mode, high DPI, fullscreen-optimization off). Tip: choose the biggest resolution the game offers in its own options. SKBox scales it to your screen.

**The SK menu.** Press the Xbox button or the PlayStation button during a game (or Ctrl+Shift+O). It opens over the game with: Resume, SKBox home, Messages (SKchat), Music (skip, pause, volume, radios), Quick play (switch games), Players and controllers, Volume, Screenshot, Close game, Power. If a controller has no home button, hold Start+Back (Xbox) or Share+Options (PlayStation) for a second.
For the menu to show over a game, the game must not use "exclusive fullscreen". Auto mode makes games borderless, which works. If you use Xbox Game Bar, turn off its controller shortcut (Windows Settings > Gaming > Xbox Game Bar > "Open Xbox Game Bar using this button on a controller").

**Controllers and Player 2.** Xbox and PlayStation (DualShock 4 / DualSense) controllers work over cable or Bluetooth. Pair them in Windows first (Settings > Controllers > Pair a Bluetooth controller). The first controller is Player 1. When a second controller connects, SKBox asks that player to pick their profile and they are in, on the home screen or in a game. Buttons show as Xbox or PlayStation symbols depending on the controller you used last.

**Music keeps playing.** SKMusic runs in its own background window, so your music continues while you game. Control it from the SK menu.

## New in 1.7
- **Each controller belongs to one player.** Player 1's controller cannot use Player 2's things (and the other way round). The highlight turns orange with a P2 tag when Player 2 moves, and the player chips glow. A third controller does nothing while two people play.
- **Choosing controllers is easy:** Settings > Controllers > "Choose which controller is Player 1 and 2" (press A on each), one-press "Swap", or Y on a player chip on Home. Player 2 joins by pressing Start on a second controller.
- **Xbox / PS button over fullscreen games, including exclusive fullscreen.** The helper tells SKBox which window was in front when you pressed the button. SKBox minimizes it so the screen is released, shows the menu, and restores the game when you press Resume. Also turns off both Game Bar switches (UseNexusForGameBarEnabled and GamepadNexusChordEnabled) so Windows hands the button to SKBox.
- **Remote play: Fix black screen.** A fullscreen game that streams black can be fixed from the player's top bar (leaves exclusive fullscreen with Alt+Enter, then makes the window borderless). The PC also hints when the picture looks frozen.

## New in 1.6: Remote play
Settings > Remote play turns this PC into a game-streaming host for a Mac or another PC on the same Wi-Fi. It only runs while you switch it on. The player app is in `remote-client/` (built for Mac and Windows by the **Build SKBox Remote** workflow when you push a tag like `remote-v1.0.0`), and the same page is served by SKBox itself so any browser works. See REMOTE-PLAY.md.

## New in 1.5
**Fixes**
- The SK menu could show up but ignore the controller: re-creating the menu window left a stale "closed" event that wiped the new window. Fixed. The controller now also reaches the menu through two paths at once (browser and native helper) and duplicates are dropped.
- Settings > Controller test shows live presses and which path saw them.
- Settings menu scrolls now that it has more pages.

**New features**
- Collections (Library > Y > Add to collection, "Show" chip filters All / On Home / Played lately / your collections)
- Sleep timer (Settings > Power): sleep, shut down or close the game after 30 min to 2 h
- Play stats page (total time, most played, longest session, launches)
- Back up and restore apps, pins, settings and play time (Settings > About)
- Preferences: look (Midnight / OLED black / Daylight), text size, 12/24-hour clock, screensaver, vibration, swap A/B, swap X/Y, boost game priority, CPU and memory display (Home and SK menu), open an app when SKBox starts
- Ctrl+Shift+S saves a screenshot from anywhere
- Controller vibration tick, low-battery warning, remembered Library sort and filter, screensaver clock that wakes on any button

## New in 1.4
- **SK menu over every fullscreen game.** While a game runs, the menu opens as a full page (a game in exclusive fullscreen just minimizes behind it, and Resume brings it back). Settings > Xbox / PS button > Menu style can switch to the see-through overlay, which only works for Borderless or Windowed games.
- **Controller works in the SK menu.** The native helper sends controller input straight to the menu, so it no longer needs window focus.
- **Screenshots** are shown in Settings > Screenshots (view, delete, open folder). In a game, the screenshot button in the SK menu returns to the game first, then captures.
- **Controller battery** (Xbox controllers) next to the controller icon on Home.
- **What's new** window after each update, and Settings > What's new.
- Library tile icon and label are centered. Quick play in the SK menu lists your most recent apps first.

## New in 1.3
- **Library and pins.** Home only shows what you pin. Library > X pins or unpins. Y on a Home tile: Move left / Move right, Unpin, Change cover art and more. Apps you add go to the Library; pin the ones you want on Home. On first update everything you already had is pinned so nothing disappears.
- **Close a game.** A Close game button appears on Home while a game runs, Y on a running app offers it, and the SK menu has it too. SKBox asks the game to close first (so it can save), then forces it after 3 seconds.
- **Xbox / PlayStation button.** Windows grabs the Xbox button for Game Bar before SKBox can see it. SKBox now turns off just that one Game Bar shortcut (Settings > Xbox / PS button, switch it off to give it back). That page also shows whether the controller helper is running and counts the button presses it sees, so you can tell what is going on. A second path covers PlayStation pads that report the PS button to the browser, and these chords still work: Start + Back, LB + RB + Back, Share + Options, Ctrl+Shift+O.
- **Bluetooth in SKBox.** Settings > Bluetooth: Scan, Pair, Forget. Devices that ask for a PIN (some keyboards) still need the “Open Windows Bluetooth” button.
- **SKchat and SKMusic with a controller.** The D-pad now jumps between buttons and links with a highlight ring (like a console), the left stick is still a mouse pointer, the right stick scrolls. A music chip on Home shows the song and pauses or plays it.
- New icon.

## Controls
| Controller | Keyboard | Does |
|---|---|---|
| D-pad / left stick | Arrow keys | Move |
| A | Enter | Select |
| B | Esc | Back |
| X | | Backspace (on-screen keyboard); in Library: pin / unpin |
| Y | F2 | Options |
| LB / RB | Tab | Library: change sort |
| Start | Home | Settings |

Return to SKBox from a game: Ctrl+Shift+B, or click the SKBox icon in the system tray.

## Put it on GitHub and build the installer
1. Make a new public GitHub repo and upload everything in this folder (keep the .github folder).
2. Settings, Actions, General, Workflow permissions: Read and write.
3. Releases, Draft a new release, tag v1.0.0, Publish.
4. When Actions turns green, download SKBox-Setup-1.0.0.exe from the release and install it.
To update later: raise "version" in package.json, publish a release with the matching tag. Installed copies update themselves.

## Optional: boot straight into SKBox instead of the Windows desktop
By default SKBox starts when you sign in to Windows. To replace the desktop completely:
1. Win+R, type regedit.
2. Go to HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\Winlogon
3. New, String Value, name it Shell, value: C:\Users\YOURNAME\AppData\Local\Programs\SKBox\SKBox.exe
To undo it: press Ctrl+Shift+Esc, File, Run new task, type regedit, delete that Shell value, then run explorer.exe.
If you quit SKBox in this mode you get a blank screen, so use Power > Restart instead.

## Notes
- Wi-Fi uses Windows' netsh and expects English Windows.
- Bluetooth pairing happens in Settings > Bluetooth (it uses the same Windows Bluetooth service as Windows Settings).
- Controller buttons only work while SKBox is in front. After launching a game, use that game's own controls.
- The installer is not code-signed, so Windows SmartScreen shows "More info, Run anyway" the first time.

## About the art and music
All wallpapers, icons, sound effects and music were made for SKBox. They are inspired by the mood of Western, block-building and neon-city games but contain no artwork, logos, characters or music from any game, so they are safe to ship.
You can still use your own images (including official game art you own) as wallpapers and profile pictures: Settings > Backgrounds & sound > Use my own image, or Y on your profile > Choose an image.
The music and sounds are generated live inside the app, so they add no download size and work offline. Music pauses automatically when SKBox is hidden or while SKchat/SKMusic is open.
