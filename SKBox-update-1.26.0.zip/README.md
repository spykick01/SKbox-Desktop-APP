# SKBox

## 1.26.0: Server dashboard, file manager, old color themes back

- **Server dashboard** (SKServers > a server > Dashboard): Start/Stop/Restart, players online out of the max, live CPU and memory (with charts), uptime, the join address (hidden by default), the console with a command box, **Save world** and **Copy log**. Stopping or restarting with players online asks first. CPU is a share of the whole PC; on Windows it is read from the Java process with a small PowerShell loop.
- **Server list**: cards show status, players, CPU and memory; running servers come first; the list opens on the server you used last; a summary line shows servers running and players online.
- **File manager** (each server's **Files** tab, and **Settings > File manager** for servers, backups, Screenshots, Downloads, Desktop, Documents and SKBox data): browse, edit text files (keyboard view, or line by line with the on-screen keyboard for a controller), add files or folders from your PC, rename, copy, move, zip, unzip, turn plugin jars off and on, copy a path, sort by name, size or date, filter. It remembers the last folder per server and warns before deleting the world, jar, plugins or settings. It can never leave the chosen folder.
- **Themes**: your old **color themes** (Midnight, OLED black, Daylight, Sunset, Ocean, Forest, Rose, Cyber, Graphite, Sakura) are cards on the Themes page again, plus 14 new ones. Picking one switches to SK Glass and sets the accent. SK Glass and Pixel Craft are listed first; the other six looks are under "More looks".
- **Backgrounds**: 8 pixel worlds (Plains, Night, Nether, End, Cave, Ocean, Snow, Desert), 6 soft-glow backgrounds and 8 more gradients, grouped in the picker.
- **Settings menu**: with the mouse, hovering only highlights and a click opens the page; a page filling in beside the menu no longer pulls the cursor out of it; B goes back to the menu first, then Home.
- **SK menu focus**: the menu now focuses the page inside its window and keeps asking for about four seconds until it really has focus (for fullscreen emulators such as Cemu).
- **Home**: hovering a game no longer shows its file location; it shows the kind of app, your play info and a short description when game info exists.
- **Import a server**: new "Type or paste a path" option, file pickers always come to the front, errors are shown instead of silently ignored, the Minecraft version is also read from `version_history.json`, the cache folder and the log, and a `user_jvm_args.txt` file alone no longer makes a Paper server look like Forge.

## 1.25.0: Real themes, server import, easier server pages

- **Themes** (Settings > Themes): a theme is a whole look, not just colors. **SK Glass** (the original, still uses your color theme and accent), **Pixel Craft** (blocky, bevelled, a pixel sky and ground), **Retro Terminal** (green phosphor, scanlines), **Game Boy** (four greens, pixel type), **Synthwave** (neon sunset and a glowing grid), **Aurora** (drifting lights behind frosted glass), **Neo Brutal** (thick outlines and hard shadows) and **Paper** (warm and calm, serif type). Each brings its own colors, fonts, shapes and backdrop, and the SK menu wears it too. Animated effects can be turned off. Works with both Classic and Deck.
- **Modes**: only **Classic** and **Deck** remain. Anyone who had picked a removed mode is moved to Classic.
- **Server page menus fixed**: moving down the menu no longer jumps the cursor into the page; B steps back to the menu before leaving; the Store menu behaves the same. Game settings can be changed while the server is running: changes are saved and apply at the next restart (with Restart now and Discard buttons).
- **Import a server** (SKServers > Import a server): pick an existing server folder or a .zip. SKBox works out the software (Paper, Purpur, Fabric, Vanilla or a plain jar) and version, shows what it found, then copies it into SKBox (your original is untouched) or uses it where it is. Forge and NeoForge are not supported yet. Also: **import a world**, **export a server** to a zip on the Desktop, a server **icon**, a **daily restart** with in-game warnings, and a **Players** tab (online players, operators, whitelist, bans).
- **Your servers stay across updates**: servers live in SKBox's own data folder, which updates and the installer never touch (uninstalling does not delete it either). SKBox also keeps a backup copy of its settings files, a mirror list of your servers, and a small file inside each server folder, so it can rebuild the list on its own if its settings were ever lost. A server whose folder was moved is flagged and can be re-pointed with Locate folder.
- Fonts used by the themes are open-licence (SIL OFL): Press Start 2P, VT323, Orbitron, Archivo Black and Lora. Licences are in `renderer/assets/fonts/LICENSES.txt`.

## 1.24.0: playit.gg, more modes, tidier Settings

- **playit.gg (no port forwarding)**: SKServers > your server > Overview > "Let friends join from anywhere". SKBox downloads playit's own signed agent (it checks the publisher's signature before running it), you approve it once on playit.gg (a link and a QR code, so you can do it on your phone), and SKBox makes a Minecraft Java tunnel and shows the address friends paste into Minecraft. The tunnel opens when the server starts and closes when the last playit server stops. Free playit accounts have their own limits. Java Edition only for now.
- **Addresses hidden by default**: IPs and the playit address show as dots on the server page, and are masked in the console. Tap Show to reveal for one visit, or switch "Hide addresses" off in Server options. Copy always works without showing anything.
- **Three more modes** (Settings > Look & modes): **Arcade** (neon cabinet, glowing carousel), **Zen** (a big clock and a few favorites) and **Wall** (dense wall of covers with collection tabs).
- **Settings, tidied**: grouped into Connect, Play, Look & sound, Social, Tools and System; searching works for every page; moving down the list is smooth (the page draws when you stop, and settings are not written to disk on every step); a toggle that refreshes a page keeps your scroll position and your place.
- **SKServers QOL**: back up automatically when a server stops, Windows notifications when it is ready (and optionally when players join), console filter (everything / players and chat / problems), recent commands, duplicate a server, Y on a server card for quick actions.
- **Spotlight**: "Surprise me: launch a random game".
- **Bug fixes**: pressing Stop while a server was still "Starting" did nothing and the server started anyway; two servers starting together could both download Java into the same file; the Wall/Cinema/Deck screens and the party panel redraw issues found by testing.

## 1.23.0: Parties, modes, Spotlight

- **Party (voice chat)**: SK menu > Party. Start a party and share the 6-character code or the invite link, or join with a code. Up to 8 people, mute and deafen, per-person volume (left/right), a talking highlight, party chat, host controls (lock, remove). The voices keep running in a hidden window while you play. Ctrl+Alt+Shift+V mutes your party mic anywhere. Friends without SKBox join from the web page in `web/party/` (see `web/party/README.txt`). Voices go straight between friends; only the handshake uses the free PeerJS service (you can point SKBox at your own server in Settings > Party).
- **SK menu 2.0**: grouped sections (Play, Social, System), a quick bar (volume, screenshot, party mic), a live party badge.
- **UI modes** (Settings > Look & modes): **Classic** (the original), **Cinema** (big banner for the focused game, shelves of posters, pill navigation) and **Deck** (side rail, resume card, tight grid, status bar). They also frame the Library and Settings.
- **Loading screens**: Orbit, Pulse, Game art, Terminal, Tips, Classic, or Surprise me. Used at startup and when a game launches. Preview in Settings > Look & modes.
- **Spotlight search** (press `/` or Ctrl+K, or the search button): games, settings pages, servers (start or stop), party and mode commands.
- **Home widgets**: Party, Servers and Today. Turn them off in Look & modes.
- **Move to another PC**: export your settings, library and stats to one file, import it elsewhere. A copy of the current setup is kept first, and secrets (PINs, tokens) are never exported.

## 1.22.0: SKServers and SKStore

- **SKServers** (Library > SKServers, pin it to Home with X): make and run Minecraft servers on this PC, like Squidservers but on your own computer. Pick Paper, Purpur, Fabric or Vanilla and a version (1.17 and newer, including the new 26.x numbers), accept the Minecraft EULA, and SKBox downloads the server (checked against the publisher's checksum) and the right Java (21 or 25) if you do not have it. Start, stop and restart, a live console with quick commands (op, whitelist, save, time), who is online, game settings (game mode, difficulty, view distance, PvP, whitelist, MOTD and more), backups with restore, update the server software, start with SKBox and restart after a crash. Servers are stopped cleanly (worlds saved) when SKBox closes.
- **Plugin and mod store** (SKServers > your server > Plugins or Mods): search Modrinth (Paper, Purpur, Fabric) and SpigotMC (Paper, Purpur), featured picks, one-tap packs (starter, Bedrock crossplay with Geyser, live map), automatic required add-ons, version fit checks, checksum checks, turn off / remove, and update checks for Modrinth plugins.
- **SKStore** (Library > SKStore): Featured, Free to play, Steam deals, top sellers and new releases, this week's free Epic games, and an Apps and tools list (Minecraft Launcher, Prism, Steam, Epic, GOG, Xbox, RetroArch, PCSX2, PPSSPP, Discord, Spotify, VLC, OBS, Sunshine, Moonlight, Parsec). Games install through Steam or Epic. Apps install with winget (Windows' own package manager) and can be added to your Library in one tap. Search covers Steam and the apps list.
- Only search words, game ids and the Minecraft version leave this PC. Nothing needs an account or key.

## 1.21.0: three big features

- **Game library (ROMs & emulators)** (Settings > Game library): add your ROM folders and SKBox sorts the games by system (Wii U, GameCube/Wii, Switch, PS1, PS2, PSP, 3DS, DS, GBA), finds your emulators, and adds each game ready to launch with the right arguments, a collection per system and cover art. Cemu, DuckStation and melonDS can be downloaded and updated from GitHub inside SKBox (needs Windows' Expand-Archive). Folders named after systems settle .iso files; unclear ones ask you. Disc images count as one game (.cue), Wii U game folders are found through code/*.rpx.
- **Game info hub**: Details now shows the description, genres, developer, release date, Metacritic score, screenshots (with a viewer) and the trailer (plays inside SKBox), from the Steam store with Wikipedia as a fallback. Only the game's name (or Steam id) is sent. Cached for 30 days. The Library can filter by genre and the info line shows genre and year. Settings > Apps > Fetch game info for all games; Extras > Look up game info automatically.
- **Phone companion** (Settings > Phone companion): your phone becomes a remote. Scan the QR code or open the address, type the PIN, then start games, add to Up next, open the SK menu, close the running game, change volume, use the screen as a trackpad (tap, two-finger right click and scroll, double-tap-drag) and a keyboard with text typing. Home Wi-Fi only, PIN required, five wrong tries lock the device out for a minute, off by default and when SKBox closes. Lock and sleep from the phone are a separate switch (off by default); shut down is never allowed.
- The CSP now allows https video (trailers). The QR code library (qrcode-generator, MIT) is bundled in renderer/vendor.

## 1.20.0

- **Big: Game Details** (Y on a game > Details): time played, launches, average and longest session, a 14 day chart, recent sessions, notes, and shortcuts.
- **Big: Save backups** (Y > Save backups, or Details): pick a game's save folder, back up now, optionally before it starts and after it closes, keep the newest 3 to 20, and restore. Restoring makes a safety copy first and refuses while the game runs. Folders over 2 GB and drive roots are refused.
- **Big: Routines** (Settings > Routines): at a set time start an app, turn Remote play on or off, show a reminder, pick tonight's game, sleep or lock the PC. Daily, weekdays or weekends. SKBox has to be running.
- **Big: History & Wrapped** (Settings > History & Wrapped): every play session is recorded; Wrapped shows totals, top games, longest session, favourite day and time and best streak for a week, month, year or all time. Copy a summary or export a CSV to the Desktop.
- **Big: Steam & Epic import** (Settings > Import apps): finds installed Steam and Epic games and adds them. They start through the launcher (steam://, com.epicgames.launcher://).
- QOL: rename, copy path, open folder and Play next in the Y menu; smaller tiles; hours badge; NEW badge; settings search; Never played and Played this week filters; reset or pin from Details; copy Wrapped; export CSV; routine Run now; Wrapped period.
- Small: daily play goal, streak saver, quiet hours, notification history, idle close for the SK menu, start screen choice, shortest session to record, default backups to keep, game notes.

## 1.19.0

- **SKBrowse is removed**: the browser, extensions, ad blocker, browser apps, the streaming hub, Watch hub and Continue watching are gone. Old browser apps are cleared from your Library on start.
- **Cemu / emulators**: SKBox now watches an emulator window itself (PowerShell, no helper needed) and keeps it borderless and 1 pixel short of the monitor, which is what Remote play can capture. It starts 8 seconds after launch if the helper has not already done it.
- **SK menu inside games**: a watcher reads the controller directly while a game runs: the Xbox / PS button or holding Back + Start opens the menu, even when the game has the keyboard focus. The menu also keeps asking Windows for focus for a couple of seconds after it opens. Switch: Extras > Open the SK menu from inside games.

## 1.18.0

- **Big: Watch hub.** A new Watch tile in the Library (pin it to Home with X): Continue watching, all your streaming apps, Watch later and a YouTube search in one screen.
- **Big: Milestones.** 23 badges earned by playing, streaks, watching and setting things up. Settings > Milestones shows progress; a notification pops up when you unlock one.
- **Big: Up next.** Line up games and shows (Y > Add to Up next, or Settings > Up next). When a game closes SKBox asks if you want to start the next one. Reorder with Y and X.

## 1.17.1

- Emulators: if the helper does not fit a Cemu (or other emulator) window within 20 seconds, SKBox now does it itself (borderless, covers the monitor, streamable) and says so. VidAngel: the compatibility layer now also provides chrome.cookies, which VidAngel uses for your streaming accounts. Remove and reinstall the extension once.

## 1.17.0

- **Fix: Cemu and Remote play.** SKBox no longer passes Cemu's `-f` flag (its own exclusive-style fullscreen, which Remote play cannot capture). SKBox makes Cemu a borderless full-screen window itself, like Hollow Knight. Extras > Emulator window style changes it back.
- **Fix: VidAngel in SKBrowse.** A compatibility layer carries messages from a website to its extension and applies declarativeNetRequest rules (block, redirect, header changes), so extensions like VidAngel can run. Reinstall the extension from the Web Store inside SKBrowse once.
- **Big: Playtime dashboard** (Settings > Play stats): chart, streak, ranking with bars, 7/14/30 day view, reset one game.
- **Big: Continue watching** (Settings > Continue watching): the last show of each streaming app, plus Watch later from SKBrowse. Tiles show "Continue: title".
- **Big: Game profiles** (Y on a game > Game profile): Remote play quality, brightness, close method, time limit, program before/after, action when you stop.
- Features: after-game action (lock/sleep/shut down with a 45 second cancel window), start/stop programs per game, emulator window style, find missing covers for every app, Surprise me, System info page, duplicate an app, hide apps from the Library, controller battery warning, close SKBrowse windows when a game starts, Watch later in SKBrowse, Monday play report.
- QOL: remembers the last Settings page, hides the mouse cursor when idle, copy play summary, copy system info, reset one game or all stats, stats range, per-game profile reset, copy a profile to every emulator, Hidden apps filter, cancel button on the Power page.

## 1.16.0
- **Cemu / shortcuts:** apps added as `.lnk` shortcuts are now resolved to the real program when launched, with the shortcut's own arguments and Start-in folder. Before, Windows opened the shortcut itself, so SKBox had no program to follow: Cemu was not recognised, `-f` full screen was never added and no window was fitted.
- **Import apps** (Settings > Import apps): scans Start Menu and Desktop shortcuts, lists the real programs (emulators first, uninstallers and updaters hidden) and adds the ones you tick.
- **Remote play sound:** stereo Opus at a chosen bitrate (Settings > Remote play > Sound quality), no echo cancellation / noise suppression / auto gain on game sound, a small audio jitter cushion, and a loudness limiter in the player so loud scenes stop distorting. The "extra sharp" video quality now actually saves.
- **Extensions:** installing one now tells you if it needs Chrome features SKBrowse lacks. VidAngel is one of those (it needs messages from vidangel.com and request rewriting), so it is now a Streaming services entry that opens in your own Chrome or Edge profile, where you install the extension once.


## 1.15.0
- **Protected video (DRM) inside SKBrowse.** SKBox now builds on castLabs Electron, which downloads Google's Widevine on first start. Netflix, Disney+, Hulu, Max and other Widevine sites play in SKBrowse and in browser apps. No more Edge hand-off. Settings > SKBrowse & browser apps shows whether Widevine is ready.
  - Some services also check that the app is signed for "Verified Media Path". For that, make a free castLabs EVS account (https://github.com/castlabs/electron-releases/wiki/EVS) and add repo secrets `EVS_ACCOUNT_NAME` and `EVS_PASSWD`. The release build then signs SKBox automatically. Without them everything else still works.
- **VidAngel for Chrome**: Settings > SKBrowse & browser apps > Install VidAngel for Chrome (also in SKBrowse > Menu > Extensions).
- **Controller in SKBrowse**: the window now takes real Windows focus, and the SKBox helper forwards controller input to it as a backup.
- **Cemu** is started with its own full screen (`-f`) whenever a game is passed in the app's arguments.


## 1.14.1 fixes
- SKBrowse opened as a hidden window, so you landed on the Windows desktop. It now shows at once and takes focus, so the controller works in it.
- The main SKBox window kept reading the controller while the SK menu or SKBrowse was in front, which moved the home screen behind the menu and pressed things (like opening SKBrowse). It now ignores the controller until it is in front again, and SKBrowse pages pause while the SK menu is open.
- Netflix, Disney+, Hulu, Max, Prime Video and other protected sites typed or clicked in SKBrowse now open in an Edge window automatically.
- Windows page (Settings and the SK menu): tap windows to select them, then Close selected or Force close selected. Select all others / none.
- Emulator fullscreen: see the notes in the release message.


## What's new in 1.14.0
- **BIG: Streaming services hub** (Settings > Streaming services). One tap adds YouTube, Twitch, Kick, Pluto TV, Tubi, Plex, Rumble, Vimeo, Dailymotion, Roku Channel, SoundCloud, Crunchyroll, Netflix, Disney+, Hulu, Max, Prime Video, Peacock, Paramount+, Apple TV+, YouTube TV and Spotify as apps with their icons. "Add all free services" does the free ones at once. Protected services open in an Edge window. Apps in SKBrowse resume where you left off.
- SKBrowse: private window, reopen my tabs, forget cookies on close, tracking-parameter stripping, Do Not Track, permission pop-up blocking, always-https, cookie banner hider, auto Skip Intro / Next Episode, hide the mouse over videos, video speed keys and menu, reader mode, mobile/desktop site, save as PDF, make this site an app, go to copied link, close other tabs, mute all, all-tabs list, search for selected text, save image, your own blocked sites, ad-block allow-list manager, lifetime blocked counter, clock in the bar.
- Per browser app: resume, start muted, start with the bar hidden, window instead of fullscreen, dark pages, zoom.
- Hotkeys: Ctrl+Alt+Shift+B opens SKBrowse, +H hides it, +M shows the desktop, +T opens Task Manager.
- Tidy up: clear cookies, cache, history, bookmarks or downloads list; export bookmarks; reset SKBrowse options; filter list updates itself weekly.


## What's new in 1.13.0
- **SKBrowse**: a built-in browser (tabs, bookmarks, history, downloads, find, zoom, picture-in-picture, dark pages, new-tab page). Works with the controller: left stick = cursor, A = click, Y = keyboard, **Start = SKBrowse menu**, View = back to SKBox.
- **Ad blocker**: blocks ad and tracker hosts, hides ad boxes, skips YouTube ads. Per-site off switch. Settings > SKBrowse > Update the filter list downloads a bigger list.
- **Chrome Web Store**: open it in SKBrowse, open an extension, press *Add to SKBrowse* (or paste a link in Extensions). Many Chrome extensions work, not all.
- **Browser apps** (Settings > SKBrowse & browser apps): type a website and it becomes an app locked to that site (no address bar, other sites are blocked), with its own logins, its own ad-block switch and its site icon as the cover (auto). Sites that play protected shows (Netflix, Disney+, Prime, Max...) open in an Edge window instead, because SKBox's browser has no Widevine.
- **Cemu and other emulators** start in a clean full-screen window (no title bar, no menu bar) with or without Remote play. A library window keeps its menu until a game is running.
- **Stream**: new *extra sharp* preset, a faster start, 1080p60 automatically for emulators, and a fix that stops Windows throttling the hidden stream window.
- **Windows without leaving SKBox**: SK menu > Windows (switch, fit, hide, close, show desktop, Task Manager); Settings > Windows opened apps also has Switch and Fit.


A console-style media center for Windows. Starts with your PC, runs fullscreen, works with controllers.

## What's new in 1.8.0
- **Press A to start.** SKBox opens on a clock screen; press A (or the PlayStation cross), then pick Player 1's profile. Turn this off in Settings > Preferences > "Ask who is playing at startup".
- **SK menu works with the controller.** The menu window never read the controller itself, so only the mouse worked. Fixed.
- **Player highlight is at the top.** A small bar under the P1 / P2 chip shows who is using a controller. Tiles no longer get tags.
- **Fancy idle screen**: a big clock with a seconds ring, drifting colors and soft music that changes with the time of day. Settings > Preferences: when it starts, style, its music, and "Show the idle screen now".
- **More looks and sound**: 7 new themes (Sunset, Ocean, Forest, Rose, Cyber, Graphite, Sakura), 6 new wallpapers, 6 more accent colors, and 7 new music moods (Dreamy Clouds, Deep Space, Ocean Calm, Forest Morning, Late Night Jazz, Arcade Chill, Twilight Clock).
- **Remote play**: streams the monitor SKBox is on, fixes exclusive-fullscreen black screens by itself, defaults to 720p 60 for less delay, and the "Click to start" box is gone. Disconnect, Fix picture and Quality moved into the SK menu.

## What's in it
- Home screen with the apps you pinned, a clock, Wi-Fi and Bluetooth buttons and your profiles (PS5 / Steam Big Picture style)
- **Library**: every app and game lives here (SKchat and SKMusic too). Press X on an app to pin it to Home or unpin it. Sort with LB / RB (A–Z, recently played, most played), search, and see how long you have played each game
- Bluetooth right inside SKBox: pair and forget controllers, headphones and speakers without opening Windows settings
- Profiles are your SKchat accounts: sign in once, SKchat and SKMusic open already logged in
- 2 players: Player 1 uses controller 1, Player 2 presses Start on controller 2 to join and picks their own profile
- SKchat and SKMusic are built-in apps (the left stick moves a cursor, A clicks, B goes back, View/Select returns to SKBox)
- Add your own apps: type a name and a path like C:\Games\game.exe (or a link like steam://rungameid/12345). Cover art is found automatically (Steam first, then Wikipedia for older games). If nothing is found, a picker opens so you can search again with another name, paste an image link, or use your own picture. You can change it any time with Y on the tile > Change cover art
- Settings: Wi-Fi (scan and connect with the on-screen keyboard), controllers, players, apps, accent color, startup, sound, Bluetooth, power
- Cozy mode: 8 wallpapers, 24 profile pictures (Wild West, Blocky World, Neon City and Cozy packs), soft UI sounds, five generated music moods (Campfire, Rainy Lo-fi, Wild West Dusk, Pixel Garden, Neon Night) and slow floating sparkles. Picking a wallpaper picks matching music
- Updates itself from GitHub Releases

## Games: fullscreen and the SK menu
**Fullscreen, done for you.** When you start a game, SKBox puts a black screen behind it (with the cover art while it loads), finds the game's window and makes it fullscreen. This is also how older games such as the first Assassin's Creed get fullscreen without you fiddling. Each app has a Fullscreen choice (Edit app):
- Auto (recommended): fills the screen, or keeps the game's shape with black bars when it is not widescreen
- Fill the screen / Keep shape (black bars)
- Press Alt+Enter or Press F11, for games that only go fullscreen with that key (falls back to Auto if it does not work)
- Leave it alone
Turn on **Old game fixes** for very old games. It applies Windows compatibility settings to that one program (Windows 7 mode, high DPI, fullscreen-optimization off). Tip: choose the biggest resolution the game offers in its own options. SKBox scales it to your screen.

**The SK menu.** Press the Xbox button or the PlayStation button during a game (or Ctrl+Shift+O). It opens over the game with: Resume, SKBox home, Messages (SKchat), Music (skip, pause, volume, radios), Quick play (switch games), Players and controllers, Volume, Screenshot, Close game, Power. If a controller has no home button, hold Start+Back (Xbox) or Share+Options (PlayStation) for a second.
For the menu to show over a game, the game must not use "exclusive fullscreen". Auto mode makes games borderless, which works. If you use Xbox Game Bar, turn off its controller shortcut (Windows Settings > Gaming > Xbox Game Bar > "Open Xbox Game Bar using this button on a controller").

**Controllers and Player 2.** Xbox and PlayStation (DualShock 4 / DualSense) controllers work over cable or Bluetooth. Pair them in Windows first (Settings > Controllers > Pair a Bluetooth controller). The first controller is Player 1. When a second controller connects, SKBox asks that player to pick their profile and they are in, on the home screen or in a game. Buttons show as Xbox or PlayStation symbols depending on the controller you used last.

**Music keeps playing.** SKMusic runs in its own background window, so your music continues while you game. Control it from the SK menu.

## New in 1.7
- **Each controller belongs to one player.** Player 1's controller cannot use Player 2's things (and the other way round). The highlight turns orange with a P2 tag when Player 2 moves, and the player chips glow. A third controller does nothing while two people play.
- **Choosing controllers is easy:** Settings > Controllers > "Choose which controller is Player 1 and 2" (press A on each), one-press "Swap", or Y on a player chip on Home. Player 2 joins by pressing Start on a second controller.
- **Xbox / PS button over fullscreen games, including exclusive fullscreen.** The helper tells SKBox which window was in front when you pressed the button. SKBox minimizes it so the screen is released, shows the menu, and restores the game when you press Resume. Also turns off both Game Bar switches (UseNexusForGameBarEnabled and GamepadNexusChordEnabled) so Windows hands the button to SKBox.
- **Remote play: Fix black screen.** A fullscreen game that streams black can be fixed from the player's top bar (leaves exclusive fullscreen with Alt+Enter, then makes the window borderless). The PC also hints when the picture looks frozen.

## New in 1.6: Remote play
Settings > Remote play turns this PC into a game-streaming host for a Mac or another PC on the same Wi-Fi. It only runs while you switch it on. The player app is in `remote-client/` (built for Mac and Windows by the **Build SKBox Remote** workflow when you push a tag like `remote-v1.0.0`), and the same page is served by SKBox itself so any browser works. See REMOTE-PLAY.md.

## New in 1.5
**Fixes**
- The SK menu could show up but ignore the controller: re-creating the menu window left a stale "closed" event that wiped the new window. Fixed. The controller now also reaches the menu through two paths at once (browser and native helper) and duplicates are dropped.
- Settings > Controller test shows live presses and which path saw them.
- Settings menu scrolls now that it has more pages.

**New features**
- Collections (Library > Y > Add to collection, "Show" chip filters All / On Home / Played lately / your collections)
- Sleep timer (Settings > Power): sleep, shut down or close the game after 30 min to 2 h
- Play stats page (total time, most played, longest session, launches)
- Back up and restore apps, pins, settings and play time (Settings > About)
- Preferences: look (Midnight / OLED black / Daylight), text size, 12/24-hour clock, screensaver, vibration, swap A/B, swap X/Y, boost game priority, CPU and memory display (Home and SK menu), open an app when SKBox starts
- Ctrl+Shift+S saves a screenshot from anywhere
- Controller vibration tick, low-battery warning, remembered Library sort and filter, screensaver clock that wakes on any button

## New in 1.4
- **SK menu over every fullscreen game.** While a game runs, the menu opens as a full page (a game in exclusive fullscreen just minimizes behind it, and Resume brings it back). Settings > Xbox / PS button > Menu style can switch to the see-through overlay, which only works for Borderless or Windowed games.
- **Controller works in the SK menu.** The native helper sends controller input straight to the menu, so it no longer needs window focus.
- **Screenshots** are shown in Settings > Screenshots (view, delete, open folder). In a game, the screenshot button in the SK menu returns to the game first, then captures.
- **Controller battery** (Xbox controllers) next to the controller icon on Home.
- **What's new** window after each update, and Settings > What's new.
- Library tile icon and label are centered. Quick play in the SK menu lists your most recent apps first.

## New in 1.3
- **Library and pins.** Home only shows what you pin. Library > X pins or unpins. Y on a Home tile: Move left / Move right, Unpin, Change cover art and more. Apps you add go to the Library; pin the ones you want on Home. On first update everything you already had is pinned so nothing disappears.
- **Close a game.** A Close game button appears on Home while a game runs, Y on a running app offers it, and the SK menu has it too. SKBox asks the game to close first (so it can save), then forces it after 3 seconds.
- **Xbox / PlayStation button.** Windows grabs the Xbox button for Game Bar before SKBox can see it. SKBox now turns off just that one Game Bar shortcut (Settings > Xbox / PS button, switch it off to give it back). That page also shows whether the controller helper is running and counts the button presses it sees, so you can tell what is going on. A second path covers PlayStation pads that report the PS button to the browser, and these chords still work: Start + Back, LB + RB + Back, Share + Options, Ctrl+Shift+O.
- **Bluetooth in SKBox.** Settings > Bluetooth: Scan, Pair, Forget. Devices that ask for a PIN (some keyboards) still need the “Open Windows Bluetooth” button.
- **SKchat and SKMusic with a controller.** The D-pad now jumps between buttons and links with a highlight ring (like a console), the left stick is still a mouse pointer, the right stick scrolls. A music chip on Home shows the song and pauses or plays it.
- New icon.

## Controls
| Controller | Keyboard | Does |
|---|---|---|
| D-pad / left stick | Arrow keys | Move |
| A | Enter | Select |
| B | Esc | Back |
| X | | Backspace (on-screen keyboard); in Library: pin / unpin |
| Y | F2 | Options |
| LB / RB | Tab | Library: change sort |
| Start | Home | Settings |

Return to SKBox from a game: Ctrl+Shift+B, or click the SKBox icon in the system tray.

## Put it on GitHub and build the installer
1. Make a new public GitHub repo and upload everything in this folder (keep the .github folder).
2. Settings, Actions, General, Workflow permissions: Read and write.
3. Releases, Draft a new release, tag v1.0.0, Publish.
4. When Actions turns green, download SKBox-Setup-1.0.0.exe from the release and install it.
To update later: raise "version" in package.json, publish a release with the matching tag. Installed copies update themselves.

## Optional: boot straight into SKBox instead of the Windows desktop
By default SKBox starts when you sign in to Windows. To replace the desktop completely:
1. Win+R, type regedit.
2. Go to HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\Winlogon
3. New, String Value, name it Shell, value: C:\Users\YOURNAME\AppData\Local\Programs\SKBox\SKBox.exe
To undo it: press Ctrl+Shift+Esc, File, Run new task, type regedit, delete that Shell value, then run explorer.exe.
If you quit SKBox in this mode you get a blank screen, so use Power > Restart instead.

## Notes
- Wi-Fi uses Windows' netsh and expects English Windows.
- Bluetooth pairing happens in Settings > Bluetooth (it uses the same Windows Bluetooth service as Windows Settings).
- Controller buttons only work while SKBox is in front. After launching a game, use that game's own controls.
- The installer is not code-signed, so Windows SmartScreen shows "More info, Run anyway" the first time.

## About the art and music
All wallpapers, icons, sound effects and music were made for SKBox. They are inspired by the mood of Western, block-building and neon-city games but contain no artwork, logos, characters or music from any game, so they are safe to ship.
You can still use your own images (including official game art you own) as wallpapers and profile pictures: Settings > Backgrounds & sound > Use my own image, or Y on your profile > Choose an image.
The music and sounds are generated live inside the app, so they add no download size and work offline. Music pauses automatically when SKBox is hidden or while SKchat/SKMusic is open.

## v1.9.0: every game opens in windowed fullscreen
SKBox now makes each game borderless fullscreen (Preferences > "Games open in windowed fullscreen"). True exclusive fullscreen is detected and left with Alt+Enter, then the window is made borderless so it looks clean and Remote play can see it. Windows' fullscreen optimizations are kept on for every game. Per-app override: Edit app > Fullscreen.

## v1.9.1: emulators (Cemu etc.) no longer flash
Emulators get one Alt+Enter and are then left alone. The automatic picture fix is limited to one gentle step and only reacts to a truly black picture, never a still one.

## v1.10.0: Remote play only windowing + speed
Games are only touched while a Remote play player is connected: they become a borderless window (no title bar or menu, over the taskbar, 1 px short of the screen so capture stays smooth). When the player disconnects the game gets its normal window back. Faster start: encoder starts at full bitrate, streaming window no longer throttled.

## v1.10.1
Taskbar auto-hides during Remote play, leftover title bars/menus are pushed off-screen, and "Fix the picture now" also fits the game window.

## v1.11.0: lag, auto-fit, and 30 new things
**Fixes**
- Auto-fit keeps checking while Remote play is on (every few seconds, with a cooldown) and puts the game window back if the game changes it. It no longer gives up after a few tries.
- Lag: Auto quality (below), a new 540p 60 "lowest delay" preset, a CPU-encoding warning, and a faster stream start.

**15 new features** (Settings > Extras & QOL)
1. Auto quality (steps quality down on a weak connection, back up when it recovers)
2. Instant preset (540p 60, lowest delay)
3. Turn Remote play on when SKBox starts (opt-in)
4. Disconnect when nobody uses it (5 min to 1 hour)
5. Keep the PC awake while streaming
6. Hide the taskbar while streaming
7. Game window fit style (Auto / Fill / Keep shape)
8. When the player disconnects: keep playing / minimize / close the game
9. Break reminders
10. Daily play limit
11. Session summary notification
12. Panic hotkey Ctrl+Alt+Shift+K (closes the game)
13. Fit hotkey Ctrl+Alt+Shift+F
14. CPU-encoding warning
15. Notices on the player when quality changes

**15 new QOL**
Copy the Remote play address, Open game folder (Edit app), Restart SKBox (Power and Extras), Played today, Reset Extras, Open data folder, Copy diagnostics, Open helper log, Fit game window now, Undo window fit, Windows notifications on/off, Check for updates now, Send test notification, Show/hide mouse cursor in the stream, New PIN after every session.

## v1.12.0: close fix, Windows opened apps, brightness, 30 features + 30 QOL
**Fixes**: Closing a game now asks nicely, then ends every process that belongs to it (by window, by process, then by program name) and tells you if Windows refuses (a game running as administrator). Settings > Windows opened apps closes any app.
**Features (30)**: brightness control, brightness hotkeys, screen dimmer, night filter (3 strengths), night schedule, Day/Evening/Night looks, game brightness, Windows opened apps list with Close, Force close, Hide/Show, Close all other apps, memory per app, high-performance power plan while gaming, boost SKBox while streaming, stream frame rate, resolution, top bitrate, stream sound switch, session time limit, lock PC on disconnect, close a game after N hours, silence Windows notifications while gaming, Windows Game Mode, stop the Xbox button opening Game Bar, close method (ask first / force), keep smooth vs keep sharp, disconnect when the game closes, hide the taskbar while a game runs, start an app when a player connects, rest-your-eyes reminder.
**QOL (30)**: refresh list, auto-refresh, close the running game, game marked with a star, confirm before closing, hide system windows, sort windows, reset screen, dimmer hotkey (Ctrl+Alt+Shift+D), night hotkey (N), brightness step, dimmer limit, filter color, open Display / Graphics / Network settings, open Task Manager, copy PIN, copy address and PIN, clear today's playtime, last 7 days, save diagnostics to Desktop, router test, hotkey list, hotkeys master switch, quiet notifications, brightness status row, window count, restart the helper, notice on brightness change, open helper log.
